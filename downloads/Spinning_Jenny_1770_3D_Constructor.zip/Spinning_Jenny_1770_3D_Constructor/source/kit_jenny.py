"""Spinning Jenny — 16-spindle teaching reconstruction as a glue-free 3D-printable constructor.

Based on the working principle of James Hargreaves's patent No. 962 (1770) and the Science Museum Group
reconstruction 1970-174 (S2: a compact frame with splayed legs; "the wheel of the machine is almost horizontal"). Proportions, joints and clearances are a
modern engineering reconstruction for FDM printing, not measurements of a surviving original.

Joints: side frames + cross members with through-tabs locked by removable keyed pins; spindles stand in a
footstep rail and lean 18° through a collar rail; whorls, pulley, collars and wheel are press-fitted on crush ribs;
axles are held by removable stop collars; the clove (upper board) is hinged on removable pins.
"""
import math

import cadquery as cq

from common import B, C, CLR, D, K, R, T, U, WALL_MIN, press_hole, press_slot

# Assembled envelope requested for the kit: 200 × 110 × 150 mm (length × width × height).
# 16 spindles at 5.3 mm pitch fill the 88 mm between the frames; the legs splay outwards and the almost horizontal
# drive wheel is carried by a bracket (иін) hung on two beams through the spindle-end legs — it is part of the
# machine, not a separate stand. Clearances (CLR, press fits) and minimum walls are not scaled.
FL = 130.0       # frame length at the top rail (x)
SPLAY = 5.0      # each leg foot stands this much further out than its top
LEG_W = (16.0, 10.0)  # leg width: spindle end (takes the wheel-arm beams) / creel end
FH = 95.0        # frame height (z)
TH = 5.0         # frame thickness (y)
S = 88.0         # inner distance between frames
FY = S / 2 + TH / 2   # frame centre y
PROT = 6.0       # tab protrusion outside the frame
N = 16
PITCH = 5.3
SP_D = 3.5       # spindle diameter
WH_D = 6.5       # whorl diameter (alternating heights, so neighbours never touch)
SY = [-(N - 1) * PITCH / 2 + i * PITCH for i in range(N)]
TILT = 18.0      # spindle lean toward the carriage
X_SP = -42.0     # spindle foot row (x)
Z_FOOT, Z_COLLAR = 40.0, 66.0
DX_COLLAR = (Z_COLLAR - Z_FOOT) * math.tan(math.radians(TILT))
X_DRUM, Z_DRUM = X_SP + 16, 30.0
X_CREEL, Z_CREEL = 45.0, 72.0
X_GUIDE, Z_GUIDE = X_SP + 20, 78.0
BOTTOM_X = (-10.0, 25.0)
BH = S / 2 - 3   # half length of the clove boards
WX = -FL / 2 - 25     # drive wheel axis (x); the wheel rises over the spindle end
ARM_BEAM_Z = (40.0, 80.0)   # beams through the spindle-end legs that carry the wheel bracket
AB = 8.0                    # their 8 × 8 mm section
ARMS_Z = (90.0, 116.0)      # the two bracket arms that hold the wheel axle
Z_WHEEL = ARMS_Z[1] + 8 + 3 + 0.1   # wheel underside: a stop collar (3 mm) rests on the upper arm as a spacer
Z_BOTTOM = 19.0


def slot(x, zc, w=10.0, h=8.0):
    return B(x - (w + CLR) / 2, x + (w + CLR) / 2, -TH, TH, zc - (h + CLR) / 2, zc + (h + CLR) / 2)


def leg_x(z, inner=False):
    """x of the spindle-end leg's outer (or inner) face at height z — the legs splay outwards"""
    top = -FL / 2 + (LEG_W[0] if inner else 0.0)
    return top - SPLAY * (1 - z / FH)


def beam_x(z):
    return (leg_x(z) + leg_x(z, True)) / 2


def prism_xz(pts):
    """closed x-z outline extruded TH (y symmetric)"""
    return cq.Workplane("XZ").polyline(pts).close().extrude(TH / 2, both=True).val()


def side_frame():
    l0 = prism_xz([(-FL / 2, FH), (-FL / 2 + LEG_W[0], FH), (-FL / 2 + LEG_W[0] - SPLAY, 0), (-FL / 2 - SPLAY, 0)])
    l1 = prism_xz([(FL / 2 - LEG_W[1], FH), (FL / 2, FH), (FL / 2 + SPLAY, 0), (FL / 2 - LEG_W[1] + SPLAY, 0)])
    f = U(
        B(-FL / 2, FL / 2, -TH / 2, TH / 2, 85, 95),          # top rail: the carriage runs on it
        B(-FL / 2 - 3, FL / 2 + 3, -TH / 2, TH / 2, 12, 26),  # bottom rail (ends inside the splayed legs)
        l0, l1,                                                # splayed legs
        B(X_SP - 8, X_SP + 24, -TH / 2, TH / 2, 26, 85),       # spindle post
        B(X_CREEL - 9, X_CREEL + 9, -TH / 2, TH / 2, 26, 85),  # creel post
    )
    holes = [slot(x, Z_BOTTOM) for x in BOTTOM_X] + [slot(X_SP, Z_FOOT), slot(X_SP, Z_COLLAR), slot(X_CREEL, Z_CREEL)]
    holes += [slot(beam_x(z), z, AB, AB) for z in ARM_BEAM_Z]
    holes += [C(4 + CLR, TH + 2, (X_DRUM, -TH / 2 - 1, Z_DRUM), (0, 1, 0)),
              C(3 + CLR, TH + 2, (X_GUIDE, -TH / 2 - 1, Z_GUIDE), (0, 1, 0))]
    return D(f, *holes)


def member(body=None, w=10.0, h=8.0):
    """cross member along y: passes through both frames, the protruding ends take a keyed lock pin"""
    half = S / 2 + TH + PROT
    m = B(-w / 2, w / 2, -half, half, -h / 2, h / 2)
    if body is not None:
        m = U(m, body)
    pins = [C(3 + CLR, h + 2, (0, sgn * (S / 2 + TH + PROT / 2), -h / 2 - 1)) for sgn in (-1, 1)]
    return D(m, *pins)


SIN, COS = math.sin(math.radians(TILT)), math.cos(math.radians(TILT))


def footstep_rail():
    # blind seats along the 18° lean: the spindle foot rests at the rail centre (4 mm floor below)
    m = member()
    return D(m, *[C(SP_D + CLR + 0.2, 7, (0, y, 0), (SIN, 0, COS)) for y in SY])


def collar_rail():
    body = B(-5, 5 + 2 * DX_COLLAR + 3, -S / 2 + 0.6, S / 2 - 0.6, -4, 4)
    m = member(body)
    # holes follow the 18° lean of the spindles
    holes = [C(SP_D + CLR + 0.2, 20, (DX_COLLAR - SIN * 10, y, -COS * 10), (SIN, 0, COS)) for y in SY]
    return D(m, *holes)


def creel_bar():
    return D(member(), *[C(3 + CLR, 10, (0, y, -5)) for y in SY])


def lock_pin():
    return U(C(3, 14, (0, 0, 0)), C(5.5, 2, (0, 0, 14)), K(3, 2.2, 1.2, (0, 0, -1.2)))


def spindle():
    return U(C(SP_D, 58, (0, 0, 0)), K(SP_D, 1.6, 8, (0, 0, 58)))


def whorl():
    w = C(WH_D, 5)
    groove = D(C(WH_D + 1, 1.6, (0, 0, 1.7)), C(WH_D - 1.2, 1.6, (0, 0, 1.7)))
    return D(w, groove, press_hole(SP_D, 7, (0, 0, -1)))


def drum():
    body = C(12, S - 2, (0, -S / 2 + 1, 0), (0, 1, 0))
    j1 = C(4, TH + 1 + 6, (0, -S / 2 - TH - 6, 0), (0, 1, 0))
    j2 = C(4, TH + 1 + 6, (0, S / 2 - 1, 0), (0, 1, 0))
    return U(body, j1, j2)


def pulley():
    p = C(22, 5.5)
    # V groove (45° flanks) so the pulley prints flat without support
    v = U(K(22.01, 19.6, 1.5, (0, 0, 1.25)), K(19.6, 22.01, 1.5, (0, 0, 2.75)))   # flanks ~51° from horizontal
    g = D(C(24, 3, (0, 0, 1.25)), v)
    return D(p, g, press_hole(4, 8, (0, 0, -1)))


def stop_collar():
    return D(C(9, 3), press_hole(4, 5, (0, 0, -1)))


def drive_wheel():
    rim = D(C(80, 6), C(72, 8, (0, 0, -1)))
    # V-shaped band groove (45° flanks): prints without support with the wheel lying flat
    v = U(K(80.01, 77.6, 1.5, (0, 0, 1.5)), K(77.6, 80.01, 1.5, (0, 0, 3.0)))   # flanks ~51° from horizontal
    rim = D(rim, D(C(82, 3, (0, 0, 1.5)), v))
    spokes = [R(B(5, 36.5, -2, 2, 0, 4), "z", a) for a in range(0, 360, 45)]
    hub = C(14, 11.5)                       # flush with the rim underneath, so the wheel prints flat on the bed
    boss = C(9, 6, (30, 0, 0))
    w = U(rim, hub, boss, *spokes)
    return D(w, press_hole(4, 16, (0, 0, -5)), C(4 + CLR, 8, (30, 0, -1)))


def wheel_axle():
    return C(4, 47)


def crank_handle():
    return U(C(4, 6, (0, 0, -6)), C(8, 2, (0, 0, 0)), C(6.5, 10, (0, 0, 2)), K(6.5, 4.5, 2, (0, 0, 12)))




BR_X = (-FL / 2 - SPLAY - 1.5, -FL / 2 + LEG_W[0] - 1.0)   # x range of the bracket's upright


def wheel_bracket():
    """иін: an upright hung on the two arm beams (they pass through its slots) with two arms that hold the axle"""
    bar = B(BR_X[0], BR_X[1], -4, 4, ARM_BEAM_Z[0] - 6, ARMS_Z[1] + 8)
    arms = [B(WX - 7, BR_X[1], -4, 4, z, z + 8) for z in ARMS_Z]
    b = U(bar, *arms)
    slots = [B(beam_x(z) - (AB + CLR) / 2, beam_x(z) + (AB + CLR) / 2, -5, 5, z - (AB + CLR) / 2, z + (AB + CLR) / 2) for z in ARM_BEAM_Z]
    return D(b, *slots, *[C(4 + CLR, 12, (WX, 0, z - 2)) for z in ARMS_Z])


def carriage_bar():
    L = 2 * (FY + 6.6)
    bar = B(-6, 6, -L / 2, L / 2, 95, 103)
    shoes = []
    for sg in (-1, 1):
        shoe = B(-6, 6, sg * FY - 6.6, sg * FY + 6.6, 88, 95)
        shoes.append(D(shoe, B(-7, 7, sg * FY - (TH + CLR) / 2, sg * FY + (TH + CLR) / 2, 87, 95.01)))
    b = U(bar, *shoes)
    # two slots for the clove lower board, a hole for the handle
    cuts = [B(-3 - CLR / 2, 3 + CLR / 2, y - 3 - CLR / 2, y + 3 + CLR / 2, 99, 104) for y in (-(BH - 20), BH - 20)]
    cuts.append(C(4 + CLR, 7, (6.01, 0, 99), (-1, 0, 0)))
    return T(D(b, *cuts), z=-95)


def clove_lower():
    board = B(-5, 5, -BH, BH, 0, 4)
    tabs = [B(-3, 3, y - 3, y + 3, -4, 0.01) for y in (-(BH - 20), BH - 20)]
    lugs = [B(-7, -1, sg * BH - (4 if sg > 0 else 0), sg * BH + (0 if sg > 0 else 4), 4, 12) for sg in (-1, 1)]
    b = U(board, *tabs, *lugs)
    holes = [C(3 + CLR, 16, (-4, sg * (BH + 6), 9), (0, -sg, 0)) for sg in (-1, 1)]
    return D(b, *holes)


def clove_upper():
    e = BH - 4.5
    board = B(-5, 5, -e, e, 4.4, 8.4)
    knuckles = [B(-7, -1, sg * e - (4 if sg > 0 else 0), sg * e + (0 if sg > 0 else 4), 4.4, 12) for sg in (-1, 1)]
    b = U(board, *knuckles)
    return D(b, *[C(3 + CLR, 20, (-4, sg * (BH + 6), 9), (0, -sg, 0)) for sg in (-1, 1)])   # the pin passes the knuckle into the board


def hinge_pin():
    return U(C(3, 13, (0, 0, 0)), C(5.5, 1.6, (0, 0, 13)))


def carriage_handle():
    return U(C(4, 7, (0, 0, -7)), C(8, 2, (0, 0, 0)), C(7, 24, (0, 0, 2)), K(7, 9, 4, (0, 0, 26)))


def carriage_stop():
    s = B(-6, 6, -6.6, 6.6, 0, 12)
    return D(s, press_slot(-7, 7, TH, -0.01, 7))


def guide_bar():
    e = S / 2 - CLR          # turns between the frames with the sliding clearance at each end
    g = B(-4, 4, -e, e, -3, 3)
    notches = [B(-5, 5, y - 0.9, y + 0.9, 1.5, 3.01) for y in SY]
    ends = [C(3 + CLR, 9.5, (0, sg * (e + 0.5), 0), (0, -sg, 0)) for sg in (-1, 1)]
    return D(g, *notches, *ends)


def roving_peg():
    return U(C(3, 46), C(5, 1.6, (0, 0, 8)))


def tolerance_test():
    plate = B(0, 90, 0, 22, 0, 5)
    holes, marks = [], []
    for i, c in enumerate((0.25, 0.30, 0.35, 0.40)):
        x = 9 + i * 15
        holes.append(C(4 + c, 7, (x, 8, -1)))
        for k in range(i + 1):
            marks.append(B(x - 4 + k * 2.2, x - 3 + k * 2.2, 17, 20, 4.4, 5.01))
    slot_ = B(66, 66 + 10 + CLR, 4, 4 + 8 + CLR, -1, 6)   # fits the 10 × 8 mm tab of a cross member
    return D(plate, *holes, *marks, slot_)


def tolerance_peg():
    return U(C(4, 12), C(7, 2, (0, 0, 12)))


def build(kit):
    tilt_spindle = lambda y: (lambda s: R(T(s, X_SP, y, Z_FOOT), "y", TILT, (X_SP, y, Z_FOOT)))  # noqa: E731
    fr = side_frame()
    kit.part(1, "side_frame", fr, 2, "Бүйір жақтау (аяқтарымен)", "PLA/PETG, 25% толтыру",
             "Машинаның негізі: үстіңгі рейкасымен арба жүреді; ойықтарға көлденең бөлшектер кіреді",
             [lambda s, sg=sg: T(R(s, "z", 0), y=sg * FY) for sg in (-1, 1)])
    kit.part(2, "bottom_cross_bar", member(), 2, "Төменгі көлденең рейка", "PLA/PETG",
             "Екі жақтауды байланыстырады; ұштары құлыптау штифтімен бекиді",
             [(x, 0, Z_BOTTOM) for x in BOTTOM_X])
    kit.part(3, "spindle_footstep_rail", footstep_rail(), 1, "Ұршық табанының рейкасы (16 ұя)", "PLA/PETG",
             "16 ұршықтың төменгі ұшы тұратын ұялар", [(X_SP, 0, Z_FOOT)])
    kit.part(4, "spindle_collar_rail", collar_rail(), 1, "Ұршық жағасының рейкасы (16 көлбеу тесік)", "PLA/PETG",
             "Ұршықтарды кареткаға қарай 18° көлбеу ұстайды", [(X_SP, 0, Z_COLLAR)])
    kit.part(5, "creel_bar_16", creel_bar(), 1, "Ровница сөресі (16 тесік)", "PLA/PETG",
             "16 ровница қазығы тұратын сөре", [(X_CREEL, 0, Z_CREEL)])
    kit.part(6, "keyed_lock_pin", lock_pin(), 16, "Алынбалы құлыптау штифті", "PETG ұсынылады",
             "Көлденең бөлшектердің жақтаудан шыққан ұшын бекітеді (желімсіз, қайта ажыратылады)",
             [(x, sg * (S / 2 + TH + 3), z - 5) for x, z in [(BOTTOM_X[0], Z_BOTTOM), (BOTTOM_X[1], Z_BOTTOM), (X_SP, Z_FOOT), (X_SP, Z_COLLAR), (X_CREEL, Z_CREEL)] + [(beam_x(zb), zb) for zb in ARM_BEAM_Z] for sg in (-1, 1)])
    kit.part(7, "spindle", spindle(), 16, "Ұршық", "PLA (немесе Ø3,5 мм металл өзек)",
             "Айналып, талшықты ширатады және жіпті өзіне орайды", [tilt_spindle(y) for y in SY])
    kit.part(8, "spindle_whorl", whorl(), 16, "Ұршық шығыршығы", "PLA",
             "Бау арқылы айналу алатын шкив; ұршыққа тығыз кигізіледі",
             [(lambda s, y=y, k=k: R(T(s, X_SP, y, Z_FOOT + 6 + 6 * (k % 2)), "y", TILT, (X_SP, y, Z_FOOT))) for k, y in enumerate(SY)])
    kit.part(9, "drive_drum", drum(), 1, "Жетек барабаны", "PLA/PETG",
             "Дөңгелектің айналуын 16 ұршық бауына таратады", [(X_DRUM, 0, Z_DRUM)])
    kit.part(10, "drum_pulley", pulley(), 1, "Барабан шкиві", "PLA",
             "Жетек бауы оралатын шкив (барабан осінің сыртқы ұшында)",
             [(lambda s: R(T(s, X_DRUM, S / 2 + TH + 0.5, Z_DRUM), "x", -90, (X_DRUM, S / 2 + TH + 0.5, Z_DRUM)))])
    kit.part(11, "axle_stop_collar", stop_collar(), 6, "Осьтің алынбалы стопор сақинасы", "PETG",
             "Ось пен барабанның сырғып шығуын тоқтатады; біреуі дөңгелек күпшегінің астында аралық сақина",
             [(WX, 0.0, ARMS_Z[1] + 8)])
    WY = 0.0
    kit.part(12, "drive_wheel", drive_wheel(), 1, "Үлкен жетек дөңгелегі (дерлік көлденең)", "PLA",
             "Иіруші оң қолымен айналдырады; жиегіндегі ойыққа жетек бауы кигізіледі", [(WX, WY, Z_WHEEL)])
    kit.part(13, "wheel_axle", wheel_axle(), 1, "Дөңгелек осі", "PLA (немесе 4 мм өзек)",
             "Иіннің екі тесігі арқылы өтетін тік ось", [(WX, WY, ARMS_Z[0] - 1)])
    kit.part(14, "crank_handle", crank_handle(), 1, "Дөңгелек тұтқасы", "PLA",
             "Дөңгелек шабағындағы тесікке салынатын тік тұтқа", [(WX + 30, WY, Z_WHEEL + 6)])
    kit.part(15, "wheel_bracket", wheel_bracket(), 1, "Дөңгелек иіні (раманың ұршық жақ ұшында)", "PLA/PETG, 30% толтыру",
             "Ұршық жақтағы аяқтардан өтетін екі арқалыққа ілінеді; екі иінімен дөңгелек осін дерлік тік ұстайды", [(0, 0, 0)])
    kit.part(16, "carriage_bar", carriage_bar(), 1, "Жылжымалы арба (каретка)", "PLA/PETG",
             "Екі үстіңгі рейкамен жүреді; кері тартқанда 16 талшықты созады", [(0, 0, 95)])
    kit.part(17, "clove_lower_board", clove_lower(), 1, "Қысқыштың (clove) төменгі тақтайы", "PLA",
             "Арбаға тілшелерімен кіреді; талшық осы тақтайға жатады", [(0, 0, 103)])
    kit.part(18, "clove_upper_board", clove_upper(), 1, "Қысқыштың (clove) жоғарғы тақтайы", "PLA",
             "Топса штифтерінде ашылып-жабылады, 16 талшықты қысып ұстайды", [(0, 0, 103)])
    def pin_along_y(x, y_head, z, sg):
        # shank runs inward (towards the machine centre) from the head plane y_head
        return lambda s: T(R(s, "x", -90 if sg > 0 else 90), x, y_head - sg * 13, z)
    kit.part(19, "hinge_pin", hinge_pin(), 4, "Топса штифті", "PETG",
             "Қысқыштың жоғарғы тақтайы мен бағыттағыш сырықтың осі",
             [pin_along_y(-4, sg * BH, 103 + 9, sg) for sg in (-1, 1)] + [pin_along_y(X_GUIDE, sg * (S / 2 + TH), Z_GUIDE, sg) for sg in (-1, 1)])
    kit.part(20, "carriage_handle", carriage_handle(), 1, "Арба тұтқасы", "PLA",
             "Иіруші сол қолымен арбаны жылжытады", [(lambda s: R(T(s, 6, 0, 99), "y", 90, (6, 0, 99)))])
    kit.part(21, "carriage_stop", carriage_stop(), 2, "Арба стопоры", "PETG",
             "Рейкаға тығыз кигізіліп, арбаның жүрісін шектейді", [(30, sg * FY, 95) for sg in (-1, 1)])
    kit.part(22, "thread_guide_bar", guide_bar(), 1, "Жіп бағыттағыш (faller)", "PLA",
             "16 ойығы бар бұрылмалы сырық: орау кезінде жіптерді ұршыққа бағыттайды", [(X_GUIDE, 0, Z_GUIDE)])
    kit.part(23, "roving_peg", roving_peg(), 16, "Ровница қазығы", "PLA",
             "Ровница орамы кигізілетін қазық", [(X_CREEL, y, Z_CREEL - 4) for y in SY])
    kit.part(24, "tolerance_test_plate", tolerance_test(), 1, "Саңылау сынағы тақтасы (міндетті емес, 3MF табақтарында жоқ)", "Сіз қолданатын пластик",
             "4 тесік: +0,25/0,30/0,35/0,40 мм; тілше ойығы — принтердің дәлдігін тексеру", [])
    kit.part(26, "wheel_arm_beam", member(w=AB, h=AB), 2, "Иін арқалығы", "PLA/PETG",
             "Ұршық жақтағы көлбеу аяқтардан өтіп, дөңгелек иінін ұстайды; ұштары құлыптау штифтімен бекиді",
             [(beam_x(z), 0, z) for z in ARM_BEAM_Z])
    kit.part(25, "tolerance_test_peg", tolerance_peg(), 1, "Саңылау сынағы штифті (міндетті емес, 3MF табақтарында жоқ)", "Сіз қолданатын пластик",
             "Сынақ тақтасындағы тесіктерге салып көріңіз", [])
    return {"overall_mm": [FL / 2 - WX + 40, 2 * (S / 2 + TH + PROT), Z_WHEEL + 20]}
