"""Shared helpers for the 3D-printable constructor kits (CadQuery / OpenCASCADE B-rep).

Design rules (FDM, 0.4 mm nozzle):
  CLR   = 0.40 mm   sliding / removable fit (pins in holes, tabs in slots) — the upper end of the 0.30–0.40 mm range,
                    so the kit assembles on an untuned printer without a test print
  press fits (a whorl that must turn with its spindle): the hole is PRESS_GAP = 0.30 mm larger than the shaft and has
                    three crush ribs that just touch the nominal shaft — a printer that prints holes small squeezes
                    the ribs instead of jamming, an accurate one gives a snug fit
  WALL_MIN = 1.2 mm thinnest wall; load-bearing walls 1.6–2.4 mm
  print volume 220 × 220 × 250 mm
"""
import json
import math
import os
import struct
from collections import Counter

import cadquery as cq

CLR = 0.40
PRESS_GAP = 0.30
RIB_W = 0.6
WALL_MIN = 1.2
BED = (220.0, 220.0, 250.0)


def box(x, y, z, at=(0, 0, 0)):
    """axis-aligned box with its base centre at `at` (z up)"""
    return cq.Workplane("XY").box(x, y, z, centered=(True, True, False)).translate(at)


def cyl(d, h, at=(0, 0, 0), axis="Z"):
    w = cq.Workplane({"Z": "XY", "X": "YZ", "Y": "XZ"}[axis]).circle(d / 2).extrude(h)
    return w.translate(at)


def solid(w):
    s = w.val() if isinstance(w, cq.Workplane) else w
    if hasattr(s, "Solids") and len(s.Solids()) == 1:
        return s.Solids()[0]
    return s


# ------------------------------------------------------------------------------------------- STL check
def _read_stl(path):
    data = open(path, "rb").read()
    tris = []
    if data[:5] == b"solid" and b"facet" in data[:400]:
        v = []
        for line in data.decode("utf8", "ignore").splitlines():
            t = line.split()
            if t and t[0] == "vertex":
                v.append(tuple(float(x) for x in t[1:4]))
                if len(v) == 3:
                    tris.append(tuple(v))
                    v = []
    else:
        n = struct.unpack_from("<I", data, 80)[0]
        for i in range(n):
            f = struct.unpack_from("<12f", data, 84 + i * 50)
            tris.append((f[3:6], f[6:9], f[9:12]))
    return tris


def check_stl(path):
    """watertight (each edge used exactly twice, opposite directions), outward normals, no degenerate triangles"""
    tris = _read_stl(path)
    key = lambda p: (round(p[0], 4), round(p[1], 4), round(p[2], 4))  # noqa: E731
    edges = Counter()
    degenerate = 0
    vol = 0.0
    lo, hi = [1e9] * 3, [-1e9] * 3
    for a, b, c in tris:
        ka, kb, kc = key(a), key(b), key(c)
        if ka == kb or kb == kc or ka == kc:
            degenerate += 1
            continue
        for p, q in ((ka, kb), (kb, kc), (kc, ka)):
            edges[(p, q)] += 1
        vol += (a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0]) + a[2] * (b[0] * c[1] - b[1] * c[0])) / 6
        for p in (a, b, c):
            for k in range(3):
                lo[k] = min(lo[k], p[k])
                hi[k] = max(hi[k], p[k])
    open_edges = sum(1 for (p, q), n in edges.items() if edges.get((q, p), 0) != n)
    nonmanifold = sum(1 for n in edges.values() if n > 1)
    size = [round(hi[k] - lo[k], 2) for k in range(3)]
    fits = all(s <= b + 1e-6 for s, b in zip(sorted(size), sorted(BED)))
    return {
        "triangles": len(tris), "open_edges": open_edges, "nonmanifold_edges": nonmanifold, "degenerate": degenerate,
        "volume_mm3": round(vol, 1), "size_mm": size, "fits_printer": fits,
        "watertight": open_edges == 0 and nonmanifold == 0 and degenerate == 0 and vol > 0,
    }


# ------------------------------------------------------------------------------------------- export
class Kit:
    def __init__(self, root, name):
        self.root = root
        self.name = name
        self.parts = []          # dicts for the manifest
        self.placed = []         # (shape, label) for the assembled reference model
        for d in ("STL", "STEP", "3MF", "patterns"):
            os.makedirs(os.path.join(root, d), exist_ok=True)

    def part(self, num, file, shape, qty, name_kk, material, role_kk, place=()):
        """export one unique part (STL + STEP) and remember where its copies sit in the assembly"""
        s = solid(shape)
        assert s.isValid(), f"{file}: invalid B-rep"
        bb = s.BoundingBox()
        size = sorted([bb.xlen, bb.ylen, bb.zlen])
        assert all(a <= b for a, b in zip(size, sorted(BED))), f"{file}: does not fit the printer {size}"
        base = f"{num:02d}_{file}"
        stl = os.path.join(self.root, "STL", base + ".stl")
        step = os.path.join(self.root, "STEP", base + ".step")
        cq.exporters.export(s, step)
        # tessellate until the mesh is closed (thin lattices can leave a hairline crack at one setting)
        for tol, ang in ((0.02, 0.15), (0.01, 0.1), (0.035, 0.2), (0.005, 0.08), (0.05, 0.25)):
            cq.exporters.export(s, stl, tolerance=tol, angularTolerance=ang)
            report = check_stl(stl)
            if report["watertight"]:
                break
        assert report["watertight"], f"{file}: STL not watertight {report}"
        self.parts.append({"num": num, "file": base, "qty": qty, "name_kk": name_kk, "material": material, "role_kk": role_kk,
                           "size_mm": [round(bb.xlen, 1), round(bb.ylen, 1), round(bb.zlen, 1)], "stl": report, "shape": s})
        for loc in place:
            self.placed.append((loc(s) if callable(loc) else s.translate(cq.Vector(*loc)), base))
        return s

    def manifest(self):
        write_manifest(self.root, self.parts)
        with open(os.path.join(self.root, "validation_report.json"), "w", encoding="utf-8") as fh:
            json.dump([{k: v for k, v in p.items() if k != "shape"} for p in self.parts], fh, ensure_ascii=False, indent=1)

    def assembly(self, filename):
        comp = cq.Compound.makeCompound([s for s, _ in self.placed])
        bb = comp.BoundingBox()
        self.assembly_box = [round(bb.xlen, 1), round(bb.ylen, 1), round(bb.zlen, 1)]
        cq.exporters.export(comp, os.path.join(self.root, "STEP", filename))
        preview = os.path.join(self.root, "STL", filename.replace(".step", "_preview_NOT_FOR_PRINT.stl"))
        cq.exporters.export(comp, preview, tolerance=0.1, angularTolerance=0.3)
        return comp

    def interference(self, limit=0.5):
        """volume shared by any two assembled parts — with the designed clearances it must be ~0"""
        bad = []
        items = [(s, f, s.BoundingBox()) for s, f in self.placed]
        for i in range(len(items)):
            for j in range(i + 1, len(items)):
                a, fa, ba = items[i]
                b, fb, bb = items[j]
                if ba.xmax < bb.xmin or bb.xmax < ba.xmin or ba.ymax < bb.ymin or bb.ymax < ba.ymin or ba.zmax < bb.zmin or bb.zmax < ba.zmin:
                    continue
                v = a.intersect(b).Volume()
                if v > limit:
                    bad.append((fa, fb, round(v, 2)))
        return bad

    def fits(self, max_gap=0.45):
        """every assembled piece must seat against at least one neighbour (pin in hole, tab in slot, foot in channel)
        with a gap no larger than the designed clearance; returns the pieces that float"""
        items = [(s, f, s.BoundingBox()) for s, f in self.placed]
        best = [None] * len(items)
        for i in range(len(items)):
            a, fa, ba = items[i]
            for j in range(len(items)):
                if i == j:
                    continue
                b, fb, bb = items[j]
                m = max_gap + 0.01
                if ba.xmax + m < bb.xmin or bb.xmax + m < ba.xmin or ba.ymax + m < bb.ymin or bb.ymax + m < ba.ymin or ba.zmax + m < bb.zmin or bb.zmax + m < ba.zmin:
                    continue
                d = a.distance(b)
                if best[i] is None or d < best[i][1]:
                    best[i] = (fb, d)
                if d <= 1e-6:
                    break
        report = [{"piece": f, "nearest": b[0] if b else None, "gap_mm": round(b[1], 3) if b else None}
                  for (_, f, _), b in zip(items, best)]
        floating = [r for r in report if r["gap_mm"] is None or r["gap_mm"] > max_gap]
        return report, floating

    def plates(self, gap=4.0):
        """print plates (3MF): copies of every part laid out flat on 220 × 220 mm beds (shelf packing)"""
        items = []
        for p in self.parts:
            if not is_machine_part(p["file"]):
                continue   # the optional tolerance test is not part of the machine and is not on the print plates
            s = p["shape"]
            bb = s.BoundingBox()
            # print orientation: of the six ways to lay the part down, the one without downward faces that need
            # support (narrow hole ceilings ≤ 6 mm print as bridges), then the lowest one
            s = best_orientation(s)
            bb = s.BoundingBox()
            s = s.translate(cq.Vector(-bb.xmin, -bb.ymin, -bb.zmin))
            bb = s.BoundingBox()
            if bb.ylen > bb.xlen:
                s = s.rotate(cq.Vector(0, 0, 0), cq.Vector(0, 0, 1), 90)
                bb = s.BoundingBox()
                s = s.translate(cq.Vector(-bb.xmin, -bb.ymin, -bb.zmin))
                bb = s.BoundingBox()
            for _ in range(p["qty"]):
                items.append((bb.xlen, bb.ylen, s, p["file"]))
        items.sort(key=lambda t: -t[1])
        plates, cur, x, y, row_h = [], [], 0.0, 0.0, 0.0
        W, D = BED[0] - 10, BED[1] - 10
        for w, d, s, f in items:
            if x + w > W:
                x, y, row_h = 0.0, y + row_h + gap, 0.0
            if y + d > D:
                plates.append(cur)
                cur, x, y, row_h = [], 0.0, 0.0, 0.0
            cur.append((s.translate(cq.Vector(x + 5, y + 5, 0)), f))
            x += w + gap
            row_h = max(row_h, d)
        if cur:
            plates.append(cur)
        files = []
        for i, pl in enumerate(plates, 1):
            path = os.path.join(self.root, "3MF", f"plate_{i:02d}.3mf")
            cq.exporters.export(cq.Compound.makeCompound([s for s, _ in pl]), path, tolerance=0.05, angularTolerance=0.2)
            files.append({"file": os.path.basename(path), "parts": Counter(f for _, f in pl)})
        return files


def svg_pattern(path, title, polys, scale_note):
    """cutting template for fabric / felt (millimetres, 1:1 on paper)"""
    xs = [x for poly in polys for x, _ in poly["pts"]]
    ys = [y for poly in polys for _, y in poly["pts"]]
    w, h = max(xs) - min(xs) + 40, max(ys) - min(ys) + 60
    ox, oy = -min(xs) + 20, -min(ys) + 40
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:.1f}mm" height="{h:.1f}mm" viewBox="0 0 {w:.1f} {h:.1f}">',
           '<rect width="100%" height="100%" fill="#ffffff"/>',
           f'<text x="20" y="16" font-family="sans-serif" font-size="7">{title}</text>',
           f'<text x="20" y="28" font-family="sans-serif" font-size="4.5">{scale_note}</text>']
    for poly in polys:
        pts = " ".join(f"{x + ox:.2f},{y + oy:.2f}" for x, y in poly["pts"])
        out.append(f'<polygon points="{pts}" fill="none" stroke="#000" stroke-width="0.4"/>')
        cx = sum(x for x, _ in poly["pts"]) / len(poly["pts"]) + ox
        cy = sum(y for _, y in poly["pts"]) / len(poly["pts"]) + oy
        out.append(f'<text x="{cx:.1f}" y="{cy:.1f}" font-family="sans-serif" font-size="5" text-anchor="middle">{poly["label"]}</text>')
    out.append("</svg>")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out))


def deg(a):
    return math.radians(a)


# ------------------------------------------------------------------------------------------- B-rep primitives
def B(x0, x1, y0, y1, z0, z1):
    """box given by its bounds"""
    return cq.Solid.makeBox(x1 - x0, y1 - y0, z1 - z0, cq.Vector(x0, y0, z0))


def _cyl_radius(face):
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    return BRepAdaptor_Surface(face.wrapped).Cylinder().Radius()


def _clean_bbox(shape):
    """exact bounding box: drop cached triangulations first (they enlarge OCC's box by the mesh deflection)"""
    from OCP.BRepTools import BRepTools
    BRepTools.Clean_s(shape.wrapped)
    return shape.BoundingBox()


def _bed_contact(shape):
    """area of flat faces lying on the bed"""
    zmin = _clean_bbox(shape).zmin
    area = 0.0
    for f in shape.Faces():
        if f.geomType() == "PLANE" and f.BoundingBox().zmax < zmin + 0.05 and f.normalAt().normalized().z < -0.99:
            area += f.Area()
    return area


def _support_area(shape):
    """area that would need support when the part lies like this: every downward face steeper than 45° above the bed,
    except the round ceilings of small holes / pins (radius ≤ 3 mm print as short bridges) and flat ceilings
    narrower than an 8 mm bridge. Curved faces are judged triangle by triangle with the true surface normal."""
    zmin = _clean_bbox(shape).zmin
    area = 0.0
    for f in shape.Faces():
        kind = f.geomType()
        fb = f.BoundingBox()
        if kind == "CYLINDER" and _cyl_radius(f) <= 6.5:
            continue                     # holes, pins, spindles, small drums print fine without support
        if kind == "CONE" and max(fb.xlen, fb.ylen, fb.zlen) <= 13:
            continue                     # small conical tips
        if fb.zmax < zmin + 0.25:
            continue                     # lies on the bed
        if kind == "PLANE":
            n = f.normalAt().normalized()
            if n.z < -0.71 and fb.zmin > zmin + 0.25 and min(fb.xlen, fb.ylen) > 8:
                area += f.Area()
            continue
        verts, tris = f.tessellate(0.1, 0.4)
        for t in tris:
            a, b, c = (verts[k] for k in t)
            m = (a + b + c) * (1 / 3)
            if m.z < zmin + 0.25:
                continue
            ar = (b - a).cross(c - a).Length / 2
            if ar < 1e-6:
                continue
            if f.normalAt(m).normalized().z < -0.71:
                area += ar
    return area


ORIENTATIONS = [((1, 0, 0), 0), ((1, 0, 0), 180), ((0, 1, 0), 90), ((0, 1, 0), -90), ((1, 0, 0), 90), ((1, 0, 0), -90)]


def best_orientation(shape):
    """no support first, then the lowest; a tall part (> 20 mm) must stand on at least 2 mm² of bed per mm of height"""
    options = []
    for axis, ang in ORIENTATIONS:
        s = shape.rotate(cq.Vector(0, 0, 0), cq.Vector(*axis), ang) if ang else shape
        h = _clean_bbox(s).zlen
        contact = _bed_contact(s)
        stable = h <= 20 or contact >= 2 * h
        options.append((not stable, round(_support_area(s)), round(h, 2), -round(contact), s))
    options.sort(key=lambda o: o[:4])
    best = options[0][4]
    _clean_bbox(best)
    return best


MANIFEST_COLUMNS = ["file", "quantity", "name_kk", "material", "role_kk", "size_mm", "triangles", "watertight"]


def write_manifest(root, parts):
    """parts_manifest.csv through the csv module, so names with commas stay in their own column"""
    import csv
    with open(os.path.join(root, "parts_manifest.csv"), "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(MANIFEST_COLUMNS)
        for p in parts:
            w.writerow([p["file"], p["qty"], p["name_kk"], p["material"], p["role_kk"], "x".join(str(v) for v in p["size_mm"]),
                        p["stl"]["triangles"], "yes" if p["stl"]["watertight"] else "NO"])


def is_machine_part(file):
    """everything except the optional clearance test pieces"""
    return "tolerance_test" not in file


def press_hole(d, h, p=(0, 0, 0), ribs=3):
    """cutting tool for a press-fit hole along z for a shaft of diameter d: d + PRESS_GAP with crush ribs"""
    r, rh = d / 2, (d + PRESS_GAP) / 2
    hole = C(d + PRESS_GAP, h, p)
    cuts = []
    for k in range(ribs):
        rib = cq.Solid.makeBox(rh + 0.05 - r, RIB_W, h + 0.02, cq.Vector(r, -RIB_W / 2, -0.01))
        rib = rib.rotate(cq.Vector(0, 0, 0), cq.Vector(0, 0, 1), 360 * k / ribs + 90)
        cuts.append(rib.translate(cq.Vector(*p)))
    return hole.cut(cq.Compound.makeCompound(cuts))


def press_slot(x0, x1, w, z0, z1, ribs_x=(-3.0, 3.0)):
    """cutting tool for a slot that is pressed onto a plate of thickness w (y): w + PRESS_GAP with crush ribs"""
    g = (w + PRESS_GAP) / 2
    slot = B(x0, x1, -g, g, z0, z1)
    cuts = [B(x - RIB_W / 2, x + RIB_W / 2, sgn * w / 2, sgn * (g + 0.05), z0 - 0.01, z1 + 0.01) if sgn > 0 else
            B(x - RIB_W / 2, x + RIB_W / 2, -(g + 0.05), -w / 2, z0 - 0.01, z1 + 0.01) for x in ribs_x for sgn in (-1, 1)]
    return slot.cut(cq.Compound.makeCompound(cuts))


def C(d, h, p=(0, 0, 0), direction=(0, 0, 1)):
    """cylinder of diameter d and length h starting at p along `direction`"""
    return cq.Solid.makeCylinder(d / 2, h, cq.Vector(*p), cq.Vector(*direction))


def K(d1, d2, h, p=(0, 0, 0), direction=(0, 0, 1)):
    """cone / truncated cone"""
    return cq.Solid.makeCone(d1 / 2, d2 / 2, h, cq.Vector(*p), cq.Vector(*direction))


def U(*shapes):
    s = shapes[0]
    for t in shapes[1:]:
        s = s.fuse(t)
    return s.clean()


def D(s, *cutters):
    for t in cutters:
        s = s.cut(t)
    return s.clean()


def T(s, x=0, y=0, z=0):
    return s.translate(cq.Vector(x, y, z))


def R(s, axis, angle, origin=(0, 0, 0)):
    a = {"x": (1, 0, 0), "y": (0, 1, 0), "z": (0, 0, 1)}[axis]
    return s.rotate(cq.Vector(*origin), cq.Vector(*origin) + cq.Vector(*a), angle)
