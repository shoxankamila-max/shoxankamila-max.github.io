"""Kazakh yurt (XVII–XVIII c. typological teaching reconstruction) as a glue-free constructor, assembled envelope Ø200 × 150 mm.

Wooden frame printed in PLA/PETG; felt covers are NOT printed — they are cut from real wool felt (or thick
fabric) with the SVG patterns, and the bands are real wool yarn / cord, as in a real yurt.

  kerege   6 identical lattice wings printed flat (2.4 mm), bent into the round base channel (R = 96.5 mm);
           neighbouring wings overlap with half-lap end stiles and are pinned together (таңғыш → pins)
  uyq      72 poles = 66 on the kerege heads (11 per wing) + 6 on the маңдайша; the alakany end straddles a
           kerege-head tab, the square qalamy tenon enters a shanyraq socket. Sockets sit in two rows, so the
           poles come in two lengths (A: lower row, B: upper row), 36 each.
  shanyraq ring with 72 sockets + two күлдіреуіш arches joined by a halving joint
  door     two босаға, маңдайша (with 6 uyq heads), табалдырық, two сықырлауық leaves on hinge pins
"""
import math

import cadquery as cq

from common import B, C, CLR, D, R, T, U, WALL_MIN, svg_pattern

# Assembled envelope requested for the kit: Ø200 × 150 mm. The plan is reduced ×0.645 (Ø6 m → Ø193 mm kerege) and
# the heights ×0.847 (shanyraq 3.05 m → 129 mm), so the roof is a little steeper than a 1:31 scale would give.
# Joint clearances (CLR), pin and socket sizes and the minimum wall/lath sections are NOT scaled (FDM limits).
SCALE_KK = "жоспары ≈1:31, биіктігі ≈1:24"
RK = 96.5                   # kerege radius
HK = 57.2                   # kerege height
YS = 129.2                  # shanyraq centre height
RS = 24.5                   # shanyraq socket radius (centre of the ring)
TK = 2.4                    # lattice thickness (radial)
LATH = 1.8                  # lath width
STILE = 6.0
DOOR_W = 29.4
JAMB = 5.0
BASE_Z = 1.6                # the wings stand on the floor of the base channel
RD = RK - TK / 2 - JAMB / 2 - 0.8                  # door posts stand just inside the wall
GAMMA = math.asin((DOOR_W / 2 + JAMB / 2) / RD)     # the end wings are pinned onto the door posts
DOOR_Y = RD * math.cos(GAMMA)
WING_ANGLE = (2 * math.pi - 2 * GAMMA) / 6
ARC = WING_ANGLE * RK
W = ARC + STILE             # flat length of one wing (ends overlap by one stile)
HEADS = 11
PIN_D = 2.5
PIN_Y = (10.0, 29.0, 47.0)
TAB_W, TAB_H = 4.0, 6.0
ROW_Z = (-2.3, 2.3)         # socket rows relative to the ring centre
RING_OUT, RING_IN, RING_H = RS + 5, RS - 7, 10.0
KUL_R = RS - 4.2            # küldeuish feet sit inside the socket ends (1.2 mm wall)
KUL_RISE = 11.0
SOCK = 2.0 + CLR
POLE_W, POLE_T = 2.6, 2.4


def head_x(k):
    return STILE / 2 + (k + 0.5) * (W - STILE) / HEADS


FOOT, FOOT_H = TK + 2.0, 2.0    # printing foot under each wing: a tall thin curved wall stands safely on the bed


def theta_of(x):
    """flat lattice x (0 … W along the wall) → angle on the wall circle, 0 at the wing centre"""
    return (x - W / 2) / RK


def sector(r0, r1, th0, th1, z0, z1):
    """annular sector between radii r0 … r1 and angles th0 … th1 (measured from +y towards +x)"""
    ang = math.degrees(th1 - th0)
    outer = cq.Solid.makeCylinder(r1, z1 - z0, cq.Vector(0, 0, z0), cq.Vector(0, 0, 1), ang)
    inner = cq.Solid.makeCylinder(r0, z1 - z0 + 0.02, cq.Vector(0, 0, z0 - 0.01), cq.Vector(0, 0, 1), ang)
    return R(outer.cut(inner), "z", 90 - math.degrees(th1))


def at_angle(local, th):
    """a solid built at the +y side of the circle (x tangential, y radius, z up) turned to angle th"""
    return R(local, "z", -math.degrees(th))


def clip_rect(pts, x0, x1, y0, y1):
    """Sutherland–Hodgman clip of a convex polygon to a rectangle"""
    def clip(poly, inside, cut):
        out = []
        for i, a in enumerate(poly):
            b = poly[(i + 1) % len(poly)]
            if inside(b):
                if not inside(a):
                    out.append(cut(a, b))
                out.append(b)
            elif inside(a):
                out.append(cut(a, b))
        return out
    lerp_x = lambda a, b, x: (x, a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0]))  # noqa: E731
    lerp_y = lambda a, b, y: (a[0] + (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]), y)  # noqa: E731
    for inside, cut in ((lambda q: q[0] >= x0, lambda a, b: lerp_x(a, b, x0)), (lambda q: q[0] <= x1, lambda a, b: lerp_x(a, b, x1)),
                        (lambda q: q[1] >= y0, lambda a, b: lerp_y(a, b, y0)), (lambda q: q[1] <= y1, lambda a, b: lerp_y(a, b, y1))):
        pts = clip(pts, inside, cut)
        if not pts:
            return []
    return pts


def kerege_wing(variant):
    """one kerege wing printed ALREADY CURVED to the wall radius (PLA is never bent): a curved plate with diamond
    openings (every crossing of two laths — a көк joint — is solid), 11 kerege heads, a printing foot and half-lap
    ends. Variant A keeps the OUTER half of both end stiles, variant B the INNER half; in the ring A and B alternate,
    so neighbouring laps meet in opposite halves."""
    r_in, r_out = RK - TK / 2, RK + TK / 2
    a = theta_of(W)
    w = sector(r_in, r_out, -a, a, 0, HK)
    p = (W - STILE) / HEADS
    u0 = HK + STILE / 2 + 0.5 * p
    v0 = HK - STILE / 2 - 0.5 * p
    d = LATH / 2 * math.sqrt(2)
    cuts = []
    for i in range(-30, 40):
        for j in range(-30, 40):
            ua, va = u0 + (i - 0.5) * p + d, v0 + (j - 0.5) * p + d
            ub, vb = u0 + (i + 0.5) * p - d, v0 + (j + 0.5) * p - d
            pts = [((u - v) / 2, (u + v) / 2) for u, v in ((ua, va), (ub, va), (ub, vb), (ua, vb))]
            pts = clip_rect(pts, STILE, W - STILE, 3.0 + FOOT_H, HK - 2.2)
            if len(pts) < 3:
                continue
            area = 0.5 * abs(sum(pts[k][0] * pts[k - 1][1] - pts[k - 1][0] * pts[k][1] for k in range(len(pts))))
            if area < 0.3:
                continue
            xc = sum(x for x, _ in pts) / len(pts)
            prism = (cq.Workplane("XZ").workplane(offset=-(r_out + 1)).polyline([(x - xc, y) for x, y in pts]).close()
                     .extrude(TK + 2).val())
            cuts.append(at_angle(prism, theta_of(xc)))
    w = w.cut(cq.Compound.makeCompound(cuts)).clean()
    tabs = [at_angle(B(-TAB_W / 2, TAB_W / 2, r_in, r_out, HK - 0.01, HK + TAB_H), theta_of(head_x(k))) for k in range(HEADS)]
    foot = sector(RK - FOOT / 2, RK + FOOT / 2, theta_of(STILE + 0.5), theta_of(W - STILE - 0.5), 0, FOOT_H)
    w = U(w, foot, *tabs)
    # half laps: remove the inner (A) or the outer (B) half of both end stiles, 0.1 mm gap between the laps
    r0, r1 = (r_in - 0.01, RK + 0.05) if variant == "A" else (RK - 0.05, r_out + 0.01)
    w = D(w, sector(r0, r1, -a - 0.01, theta_of(STILE), -1, HK + 1), sector(r0, r1, theta_of(W - STILE), a + 0.01, -1, HK + 1))
    holes = [at_angle(C(PIN_D + CLR, TK + 2, (0, r_in - 1, y), (0, 1, 0)), theta_of(x)) for x in (STILE / 2, W - STILE / 2) for y in PIN_Y]
    return D(w, *holes)


def wing_pin():
    return U(C(PIN_D, 6.2), C(4.6, 1.2, (0, 0, 6.2)))


def base_segment():
    """curved channel that holds the bottom of one wing on the radius"""
    a0, a1 = -WING_ANGLE / 2 + 0.032, WING_ANGLE / 2 - 0.032     # gaps at the joints and beside the door posts
    n = 48
    wide_in, wide_out = RK - (FOOT + CLR) / 2, RK + (FOOT + CLR) / 2      # takes the printing foot of the wing
    inner, outer = RK - (TK + CLR) / 2, RK + (TK + CLR) / 2               # holds the wall itself above it

    def ring(r0, r1, b0, b1, z0, h):
        po = [(r1 * math.sin(b0 + (b1 - b0) * i / n), r1 * math.cos(b0 + (b1 - b0) * i / n)) for i in range(n + 1)]
        pi = [(r0 * math.sin(b1 - (b1 - b0) * i / n), r0 * math.cos(b1 - (b1 - b0) * i / n)) for i in range(n + 1)]
        return cq.Workplane("XY").workplane(offset=z0).polyline(po + pi).close().extrude(h).val()
    body = ring(wide_in - WALL_MIN, wide_out + WALL_MIN, a0, a1, 0, 6)
    # slot profile in the (r, z) plane: wide for the foot, then a 45° chamfer to the wall width — no overhanging ledge
    zf = 1.6 + FOOT_H + 0.3
    step = (wide_out - outer)
    prof = [(wide_in, 1.6), (wide_out, 1.6), (wide_out, zf), (outer, zf + step), (outer, 6.5), (inner, 6.5), (inner, zf + step), (wide_in, zf)]
    span = math.degrees(a1 - a0) + 2 * math.degrees(0.01)
    slot = cq.Workplane("XZ").polyline(prof).close().revolve(span, (0, 0, 0), (0, 1, 0)).val()
    slot = R(slot, "z", 90 - math.degrees(a1 + 0.01))
    return T(D(body, slot), y=-RK)


def pole(row):
    """uyq in the (r, z) plane, thickness POLE_T; r measured from the yurt axis, origin moved to the kerege head"""
    zs = YS + ROW_Z[row]
    r_tip_in = RING_OUT - 6.0
    pieces = []
    # alakany: broad flat end with a notch that straddles the kerege-head tab
    al = B(RK - 2.9, RK + 2.9, -POLE_T / 2, POLE_T / 2, HK, HK + 12)
    al = D(al, B(RK - (TK + CLR) / 2, RK + (TK + CLR) / 2, -POLE_T, POLE_T, HK - 1, HK + TAB_H + 0.3))
    pieces.append(al)
    pts = [(RK, HK + 11), (RK - 3, HK + 19), (RK - 9, HK + 25), (RING_OUT + 0.5, zs)]
    for (r0, z0), (r1, z1) in zip(pts, pts[1:]):
        L = math.hypot(r1 - r0, z1 - z0)
        ang = math.degrees(math.atan2(z1 - z0, r1 - r0))
        seg = B(0, L, -POLE_W / 2, POLE_W / 2, -POLE_T / 2, POLE_T / 2)   # built in x-y, rotated into x-z below
        seg = R(seg, "x", 90)
        seg = R(seg, "y", -ang)
        pieces.append(T(seg, r0, 0, z0))
        pieces.append(R(C(POLE_W, POLE_T, (r1, -POLE_T / 2, z1), (0, 1, 0)), "y", 0))
    tenon = B(r_tip_in, RING_OUT + 1.0, -1.0, 1.0, zs - 1.0, zs + 1.0)
    pieces.append(tenon)
    p = U(*pieces)
    return T(p, -RK, 0, -HK)


def pole_angles():
    """angles (from +y towards +x) of the 72 poles: 66 on the kerege heads + 6 on the маңдайша, row A/B alternating"""
    wall = [GAMMA + i * WING_ANGLE + (k + 0.5) * WING_ANGLE / HEADS for i in range(6) for k in range(HEADS)]
    door = [math.atan2(x, DOOR_Y) for x in DOOR_HEAD_X]
    ang = sorted([(a + math.pi) % (2 * math.pi) - math.pi for a in wall + door])
    return [(a, i % 2, "door" if any(abs(a - d) < 1e-9 for d in door) else "wall") for i, a in enumerate(ang)]


def shanyraq_ring():
    ring = D(C(2 * RING_OUT, RING_H, (0, 0, -RING_H / 2)), C(2 * RING_IN, RING_H + 2, (0, 0, -RING_H / 2 - 1)))
    socks = []
    for th, row, _ in pole_angles():
        a = math.pi / 2 - th          # CadQuery angle from +x
        z = ROW_Z[row]
        s = B(RING_OUT - 6.3, RING_OUT + 1, -SOCK / 2, SOCK / 2, z - SOCK / 2, z + SOCK / 2)
        socks.append(R(s, "z", math.degrees(a)))
    slots = [R(B(KUL_R - (3 + CLR) / 2, KUL_R + (3 + CLR) / 2, -(3 + CLR) / 2, (3 + CLR) / 2, RING_H / 2 - 4, RING_H / 2 + 1), "z", a) for a in (45, 135, 225, 315)]
    return D(ring, *socks, *slots)


def kuldeuish(notch_from_top):
    """arch in the x-z plane: feet drop into the ring-top slots; the two arches cross with a halving joint"""
    span, rise, w, t = 2 * KUL_R, KUL_RISE, 3.0, 3.0
    pieces = []
    n = 14
    pts = [(-span / 2 + span * i / n, w / 2 + 0.2 + rise * (1 - (2 * i / n - 1) ** 2)) for i in range(n + 1)]   # band clears the ring top
    for (x0, z0), (x1, z1) in zip(pts, pts[1:]):
        L = math.hypot(x1 - x0, z1 - z0)
        ang = math.degrees(math.atan2(z1 - z0, x1 - x0))
        seg = R(R(B(0, L, -t / 2, t / 2, -w / 2, w / 2), "x", 0), "y", -ang)
        pieces.append(T(seg, x0, 0, z0))
        pieces.append(C(w, t, (x1, -t / 2, z1), (0, 1, 0)))
    feet = [B(sx * span / 2 - 1.5, sx * span / 2 + 1.5, -t / 2, t / 2, -4, w + 0.2) for sx in (-1, 1)]
    a = U(*pieces, *feet)
    z_mid = rise + w / 2 + 0.2
    notch = B(-(t + CLR) / 2, (t + CLR) / 2, -t, t, z_mid if notch_from_top else z_mid - w, z_mid + w if notch_from_top else z_mid)
    if notch_from_top:
        notch = B(-(t + CLR) / 2, (t + CLR) / 2, -t, t, z_mid - 0.01, z_mid + w)
    else:
        notch = B(-(t + CLR) / 2, (t + CLR) / 2, -t, t, z_mid - w, z_mid + 0.01)
    return D(a, notch)


LINTEL_L = DOOR_W + 2 * JAMB
JAMB_X = DOOR_W / 2 + JAMB / 2
HINGE_X = DOOR_W / 2 - 2.6
DOOR_HEAD_X = [-(LINTEL_L / 2 - 4) + i * (LINTEL_L - 8) / 5 for i in range(6)]
Z_LINTEL = HK - 6.0


def jamb():
    """post between the threshold and the lintel, with a 3 × 3 mm tenon at each end"""
    body = B(-JAMB / 2, JAMB / 2, -JAMB / 2, JAMB / 2, 5, Z_LINTEL)
    tenons = [B(-1.5, 1.5, -1.5, 1.5, 1, 5.01), B(-1.5, 1.5, -1.5, 1.5, Z_LINTEL - 0.01, Z_LINTEL + 4)]
    j = U(body, *tenons)
    pins = [C(PIN_D + CLR, JAMB + 2, (0, -JAMB / 2 - 1, y), (0, 1, 0)) for y in PIN_Y]
    return D(j, *pins)


def mortises(z0, z1):
    return [B(sx * JAMB_X - (3 + CLR) / 2, sx * JAMB_X + (3 + CLR) / 2, -(3 + CLR) / 2, (3 + CLR) / 2, z0, z1) for sx in (-1, 1)]


def lintel_piece():
    """маңдайша in its local frame (z = 0 at its underside); six uyq heads on top"""
    m = B(-LINTEL_L / 2, LINTEL_L / 2, -JAMB / 2, JAMB / 2, 0, 6)
    heads = [B(x - TAB_W / 2, x + TAB_W / 2, -TK / 2, TK / 2, 6 - 0.01, 6 + TAB_H) for x in DOOR_HEAD_X]
    m = U(m, *heads)
    hinge = [C(2 + CLR, 4, (sx * HINGE_X, 0, -0.01)) for sx in (-1, 1)]
    return D(m, *hinge, *mortises(-0.01, 4.3))


def threshold():
    m = B(-LINTEL_L / 2, LINTEL_L / 2, -JAMB / 2, JAMB / 2, 0, 5)
    hinge = [C(2 + CLR, 4, (sx * HINGE_X, 0, 1.01)) for sx in (-1, 1)]
    return D(m, *hinge, *mortises(0.7, 5.01))


LEAF_H = Z_LINTEL - 5 - 1.0


def door_leaf(side):
    w = DOOR_W / 2 - 0.6
    leaf = B(0, w, -2.5, 2.5, 0, LEAF_H)
    panels = [B(5, w - 3, 2.0, 3.1, z, z + LEAF_H * 0.38) for z in (LEAF_H * 0.08, LEAF_H * 0.54)]   # raised panels (front)
    leaf = D(U(leaf, *panels), C(2 + CLR, LEAF_H + 2, (2.6, 0, -1)))
    return leaf if side > 0 else leaf.mirror("YZ")


def door_pin():
    return C(2, LEAF_H + 7.5)


def stake():
    shaft = B(-1.6, 1.6, -1.6, 1.6, 4, 30)
    tip = cq.Workplane("XY").polyline([(-1.6, 4), (1.6, 4), (0, 0)]).close().extrude(3.2).val().translate(cq.Vector(0, 1.6, 0))
    tip = R(tip, "x", 90)
    hook = B(-1.6, 7, -1.6, 1.6, 27, 30)
    barb = B(5, 7, -1.6, 1.6, 23, 30)
    return U(shaft, T(tip, 0, 0, 0), hook, barb)


def tolerance_test():
    plate = B(0, 70, 0, 20, 0, 4)
    holes = [C(PIN_D + c, 6, (8 + i * 12, 8, -1)) for i, c in enumerate((0.25, 0.30, 0.35, 0.40))]
    socket = B(56 - SOCK / 2, 56 + SOCK / 2, 8 - SOCK / 2, 8 + SOCK / 2, -1, 6)
    marks = [B(8 + i * 12 - 3 + k * 2, 8 + i * 12 - 2 + k * 2, 15, 18, 3.4, 4.01) for i in range(4) for k in range(i + 1)]
    return D(plate, *holes, socket, *marks)


# ------------------------------------------------------------------------------------------- felt patterns
def patterns(root):
    import os
    out = os.path.join(root, "patterns")
    # tuyrlyq: 4 wall felts around the kerege (door gap left open), 6 mm overlap, hem 4 mm above the heads
    circ = 2 * math.pi * (RK + 4) - (DOOR_W + 2 * JAMB)
    tw, th = circ / 4 + 8, HK + TAB_H + 4
    svg_pattern(os.path.join(out, "tuyrlyq_wall_felt_x4.svg"), "Туырлық — 4 дана (" + SCALE_KK + "), жүн киіз 1–2 мм",
                [{"label": "Туырлық ×4", "pts": [(0, 0), (tw, 0), (tw, th), (0, th)]}], "Өлшем миллиметрмен, 100% масштабта басыңыз")
    # uzik: the roof is close to a cone from the kerege heads to the shanyraq; 4 sectors (two front, two back)
    r_out, z_out = RK + 3, HK + TAB_H
    r_in, z_in = RING_OUT + 3, YS
    slant = math.hypot(r_out - r_in, z_in - z_out)
    s_out = slant * r_out / (r_out - r_in)
    s_in = s_out - slant
    theta = 2 * math.pi * r_out / s_out
    seg = theta / 4 + 0.06
    n = 24
    pts = [(s_out * math.cos(seg * i / n), s_out * math.sin(seg * i / n)) for i in range(n + 1)]
    pts += [(s_in * math.cos(seg * (n - i) / n), s_in * math.sin(seg * (n - i) / n)) for i in range(n + 1)]
    svg_pattern(os.path.join(out, "uzik_roof_felt_x4.svg"), "Үзік — 4 дана (" + SCALE_KK + "), жүн киіз 1–2 мм",
                [{"label": "Үзік ×4", "pts": pts}], "Өлшем миллиметрмен, 100% масштабта басыңыз")
    s = 2 * RING_OUT + 16
    svg_pattern(os.path.join(out, "tundik_crown_felt_x1.svg"), "Түндік — 1 дана (" + SCALE_KK + "), бұрыштарына жіп бау",
                [{"label": "Түндік", "pts": [(0, 0), (s, 0), (s, s), (0, s)]}], "Өлшем миллиметрмен, 100% масштабта басыңыз")
    svg_pattern(os.path.join(out, "kiiz_esik_door_felt_x1.svg"), "Киіз есік — 1 дана (" + SCALE_KK + ")",
                [{"label": "Киіз есік", "pts": [(0, 0), (DOOR_W + 8, 0), (DOOR_W + 8, HK + 4), (0, HK + 4)]}], "Өлшем миллиметрмен, 100% масштабта басыңыз")


def wing_at(i):
    """wing i of the ring (A for even i, B for odd i) at its place on the wall circle"""
    th = GAMMA + i * WING_ANGLE + WING_ANGLE / 2
    return lambda s: T(R(s, "z", -math.degrees(th)), z=BASE_Z)


def lap_pin_at(theta, y):
    def place(s):
        p = T(s, 0, 0, -TK / 2 - 1.2)      # head outside, shank through both half-laps
        p = R(p, "x", 90)
        p = R(p, "z", -math.degrees(theta))
        return T(p, RK * math.sin(theta), RK * math.cos(theta), BASE_Z + y)
    return place


def build(kit):
    def on_circle(theta, r, z, rot_extra=0.0):
        return lambda s: T(R(s, "z", -math.degrees(theta) + rot_extra), r * math.sin(theta), r * math.cos(theta), z)

    kit.part(1, "kerege_wing_A", kerege_wing("A"), 3, "Кереге қанаты А (дайын иілген; шеттерінің жұқа жағы сыртта)", "PLA",
             "Үйдің қабырғасы: 11 кереге басы; 1, 3, 5-орынға қойылады, шеттері Б қанатымен қабаттасып штифтпен біріктіріледі",
             [wing_at(i) for i in (0, 2, 4)])
    kit.part(1, "kerege_wing_B", kerege_wing("B"), 3, "Кереге қанаты Б (дайын иілген; шеттерінің жұқа жағы ішінде)", "PLA",
             "Үйдің қабырғасы: 11 кереге басы; 2, 4, 6-орынға қойылады, шеттері А қанатымен қабаттасып штифтпен біріктіріледі",
             [wing_at(i) for i in (1, 3, 5)])
    kit.part(2, "wing_lap_pin", wing_pin(), 21, "Таңғыш штифті (қанат біріктіргіш)", "PETG",
             "Көрші қанаттарды және шеткі қанатты босағаға біріктіреді (7 түйіс × 3)",
             [lap_pin_at(GAMMA + i * WING_ANGLE, y) for i in range(1, 6) for y in PIN_Y])
    kit.part(3, "kerege_base_channel", base_segment(), 6, "Кереге табанының иінді науасы", "PLA",
             "Қанаттың төменгі жиегін R = 96,5 мм шеңбер бойымен ұстайды", [on_circle(GAMMA + (i + 0.5) * WING_ANGLE, RK, 0) for i in range(6)])
    poles_a = pole(0)
    poles_b = pole(1)
    def pole_at(th, kind):
        r = RK if kind == "wall" else DOOR_Y / math.cos(th)
        return lambda s: T(R(s, "z", 90 - math.degrees(th)), r * math.sin(th), r * math.cos(th), HK + BASE_Z if kind == "wall" else Z_LINTEL + 6)
    angs = pole_angles()
    kit.part(4, "uyq_A_lower_row", poles_a, 36, "Уық A (шаңырақтың төменгі қатарына)", "PLA/PETG",
             "Алақаны кереге басына мінеді, қаламы шаңырақтың төменгі көзіне кіреді",
             [pole_at(th, kind) for th, row, kind in angs if row == 0 and kind == "wall"])
    kit.part(5, "uyq_B_upper_row", poles_b, 36, "Уық B (шаңырақтың жоғарғы қатарына)", "PLA/PETG",
             "Алақаны кереге басына мінеді, қаламы шаңырақтың жоғарғы көзіне кіреді",
             [pole_at(th, kind) for th, row, kind in angs if row == 1 and kind == "wall"])
    kit.part(6, "shanyraq_ring_72", shanyraq_ring(), 1, "Шаңырақ тоғыны (72 көз, екі қатар)", "PLA/PETG, 30% толтыру",
             "Уықтарды жоғарыда біріктіреді; үстіңгі ойықтарына күлдіреуіш кіреді", [(0, 0, YS + BASE_Z)])
    kit.part(7, "kuldeuish_arch_lower", kuldeuish(True), 1, "Күлдіреуіш доғасы (астыңғы)", "PLA",
             "Шаңырақты ұстайтын доға; екінші доғамен ортасында жартылай ойық арқылы айқасады",
             [lambda s: T(R(s, "z", 45), 0, 0, YS + BASE_Z + RING_H / 2)])
    kit.part(8, "kuldeuish_arch_upper", kuldeuish(False), 1, "Күлдіреуіш доғасы (үстіңгі)", "PLA",
             "Бірінші доғаның үстінен айқасады", [lambda s: T(R(s, "z", 135), 0, 0, YS + BASE_Z + RING_H / 2)])
    kit.part(9, "esik_bosaga_jamb", jamb(), 2, "Босаға", "PLA/PETG",
             "Есіктің екі бүйір тірегі: маңдайша мен табалдырық ойықтарына кіреді, қанаттар штифтпен бекиді",
             [(sx * JAMB_X, DOOR_Y, 0) for sx in (-1, 1)])
    kit.part(10, "mandaysha_lintel", lintel_piece(), 1, "Маңдайша (6 уық басы бар)", "PLA/PETG",
             "Есіктің жоғарғы көлденеңі; үстіндегі 6 басқа есік үстіндегі уықтар мінеді", [(0, DOOR_Y, Z_LINTEL)])
    kit.part(11, "tabaldyryq_threshold", threshold(), 1, "Табалдырық", "PLA/PETG",
             "Есіктің төменгі көлденеңі", [(0, DOOR_Y, 0)])
    kit.part(12, "syqyrlauyq_leaf_right", door_leaf(1), 1, "Сықырлауық — оң жарма", "PLA",
             "Қос жармалы ағаш есіктің оң жақ жармасы, топса өзегінде ашылады", [(-DOOR_W / 2, DOOR_Y, 5.5)])
    kit.part(13, "syqyrlauyq_leaf_left", door_leaf(-1), 1, "Сықырлауық — сол жарма", "PLA",
             "Сол жақ жарма", [(DOOR_W / 2, DOOR_Y, 5.5)])
    kit.part(14, "door_hinge_pin", door_pin(), 2, "Есік топсасының өзегі", "PETG немесе 2 мм металл сым",
             "Табалдырық пен маңдайшадағы тесікке кіріп, жарманы айналдырады",
             [(sx * HINGE_X, DOOR_Y, 1.5) for sx in (-1, 1)])
    kit.part(15, "zhelbau_stake", stake(), 4, "Желбау қазығы", "PETG",
             "Желбау жібі байланатын қазық (үстел бетіне қойылады немесе құмға шаншылады)", [])
    kit.part(16, "tolerance_test_plate", tolerance_test(), 1, "Саңылау сынағы тақтасы (міндетті емес, 3MF табақтарында жоқ)", "Сіз қолданатын пластик",
             "Ø2,5 штифт үшін +0,25/0,30/0,35/0,40 мм тесіктер және шаңырақ көзінің үлгісі", [])
    patterns(kit.root)
    return {"overall_mm": [2 * (RK + 6), 2 * (RK + 6), YS + RING_H / 2 + 14]}
