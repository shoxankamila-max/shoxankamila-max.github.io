"""Builds both 3D-printable constructor kits (STEP, STL, 3MF plates, manifest, validation report).

  python scripts/print_kits/build_kits.py          # needs: pip install cadquery==2.4.0 "numpy<1.25"

Output: print-kits/Spinning_Jenny_1770_3D_Constructor/ and print-kits/Kazakh_Yurt_XVII_XVIII_3D_Constructor/
"""
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import Kit  # noqa: E402
import kit_jenny  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
OUT = os.path.join(ROOT, "print-kits")


def make(name, module, assembly_file):
    root = os.path.join(OUT, name)
    shutil.rmtree(root, ignore_errors=True)
    kit = Kit(root, name)
    info = module.build(kit)
    kit.manifest()
    kit.assembly(assembly_file)
    clashes = kit.interference()
    with open(os.path.join(root, "interference_report.json"), "w", encoding="utf-8") as fh:
        json.dump([{"a": a, "b": b, "volume_mm3": v} for a, b, v in clashes], fh, ensure_ascii=False, indent=1)
    print(f"[kit] interference: {len(clashes)} clashing pairs", clashes[:12])
    fits, floating = kit.fits()
    bb = kit.assembly_box
    with open(os.path.join(root, "fit_report.json"), "w", encoding="utf-8") as fh:
        json.dump({"assembled_bbox_mm": bb, "max_gap_mm": 0.45, "floating": floating, "pieces": fits}, fh, ensure_ascii=False, indent=1)
    print(f"[kit] assembled bounding box {bb[0]} x {bb[1]} x {bb[2]} mm; fit: {len(fits) - len(floating)}/{len(fits)} pieces seated", floating[:8])
    plates = kit.plates()
    with open(os.path.join(root, "plates.json"), "w", encoding="utf-8") as fh:
        json.dump([{"file": p["file"], "parts": dict(p["parts"])} for p in plates], fh, ensure_ascii=False, indent=1)
    print(f"[kit] {name}: {len(kit.parts)} unique parts, {sum(p['qty'] for p in kit.parts)} pieces, {len(plates)} plates")
    for p in kit.parts:
        r = p["stl"]
        print(f"   {p['file']:<34} x{p['qty']:<3} {str(p['size_mm']):<22} tris {r['triangles']:<6} watertight={r['watertight']}")
    return kit, info, plates


if __name__ == "__main__":
    which = sys.argv[1:] or ["jenny", "yurt"]
    if "jenny" in which:
        make("Spinning_Jenny_1770_3D_Constructor", kit_jenny, "Spinning_Jenny_complete_assembly.step")
    if "yurt" in which:
        import kit_yurt  # noqa: E402
        make("Kazakh_Yurt_XVII_XVIII_3D_Constructor", kit_yurt, "Kazakh_Yurt_complete_assembly.step")
